Entpacken eine Zip Archivs:
Mittlerweile sollte jeder Computer oder Laptop ein ENtpackungs Programm haben. Damit sollte das Entpacken automatisch bei Donwload des Archivs geschehen.
Nach Download des Archivs kann es jedoch auch passieren, dass die Datei erst na klicken des Archivs entpackt wird.


Spielanleitung:
1. Um das Spiel zu starten, wähle zunächst die Farben für die Spieler, die Velocity und die Precision aus.
2. Klicke anschließend auf Start.
3. Nun kannst du durch klicken auf dem Spielfeld den Ball bewegen.
4. Um den Status eines Spielers anzusehen, wähle einen Spieler aus Team 1 oder zwei über das Dropdown Menü.
5. Dort kannst du auch spieler aus dem Feld entfernen


